# SETTING UP A DATA SCIENCE ENVIRONMENT

## SETTING UP WINDOWS LINUX SUBSYSTEM 2
1. open powershell in admin
2. wsl --install, reboot

## SETTING UP WINDOWS
1. Windows & Conda setup:
	Install Miniconda
	Install MesloLGS NF fonts from this folder (or https://github.com/romkatv/dotfiles-public/tree/master/.local/share/fonts/NerdFonts)
	Run powershell (admin) and run:
		.\DataScience_SetUp_v1_Windows.ps1
	add line to Documents\PowerShell\profile.ps1
		# To run with basic theme
		# oh-my-posh --init --shell pwsh | Invoke-Expression
		# Note: change "bubblesextra" to any other theme name
		oh-my-posh init pwsh --config "$env:POSH_THEMES_PATH\bubblesextra.omp.json" | Invoke-Expression
	Restart powershell (admin) and run:
		.\DataScience_SetUp_v1_Windows_CondaLibs.ps1	
2. Windows Terminal setup
	Open settings for terminal
	Set as default application and default profile to Ubutnu
	Hide old powershell profile
	Open Json file in the lower left
	Under settings paste this in the Ubuntu section:
			{
				...
				"closeOnExit" : true,
				"fontFace" : "MesloLGS NF",
				"fontSize" : 12,
				"historySize" : 9001,
				"icon" : "ms-appx:///ProfileIcons/{9acb9455-ca41-5af7-950f-6bca1bc9722f}.png",
				"padding" : "0, 0, 0, 0",
				"snapOnInput" : true,
				"startingDirectory": "//wsl$/Ubuntu/home/nestor/"
			}
	
	And add below, a new entry for miniconda and git bash:

			{
				"guid": "{2337f50b-bd5c-4877-b127-d643395b8fe2}",
				"name": "Miniconda",
				"icon": "C:/Users/Battuto/Documents/OneDrive/Graphics/Logos/conda.png",
				"startingDirectory": "~",
				"commandline": "powershell.exe -ExecutionPolicy ByPass -NoExit -Command \"& 'C:\\Users\\Battuto\\miniconda3\\shell\\condabin\\conda-hook.ps1' ; conda activate 'C:\\Users\\Battuto\\miniconda3' \"",
				"hidden": false
			},
			{
				"guid": "{3097006c-1dc5-4a69-83ed-f251ae46dd12}",
				"name": "Git-Bash",
				"icon": "C:/Users/Battuto/Documents/OneDrive/Graphics/Logos/Git-Icon-1788C.png",
				"commandline": "C:\\Users\\Battuto\\miniconda3\\python.exe C:\\Users\\Battuto\\miniconda3\\cwp.py C:\\Users\\Battuto\\miniconda3\\ C:\\Users\\Battuto\\miniconda3\\Library\\bin\\bash.exe --login -i --"
			}
			
	Add this to the Powershell setting in Windows Terminal json settings
		"fontFace" : "MesloLGS NF",
		"fontSize" : 12,
		"elevate": true
	To hide shells (like azure and the old powershell) change "hidden": true in their guids
	
3. Install VS Code with plugins in Windows
	Extensions:
		Better Comments
		Code Spell Checker
		Code Runner
		Edit csv
		GitHub Repositories
		Git Graph
		Live Share Extension Pack
		Path Intellisense
		Markdownlint
		Python
		autoDocstring
		Jupyter
		R
		R Debugger
		Remote SSH, WSL, Development, Containers
		sourcery
		Tabnine
		YAML
	Optional:
		One Dark Theme
		Horizon Theme
		Material Icon Theme
	Settings:
		Click gear icon in lower left corner, then Command Palette, then "Python: Select Linter" and choose Flake8
		In Settings:
			Check box: "Jupyter: Send selection to interactive windows" in Jupyter extension
			rpath Windows: C:\\Users\\Battuto\\miniconda3\\Scripts\\R.exe
			Rterm: C:\\Users\\Battuto\\miniconda3\\Scripts\\radian.exe (note that this may not work as of 4/11/2023...)
			r.lsp.debug: true
			r.lsp.diagnostics: true
			r.bracketedPaste: true
			[in R: install.packages("httpgd")]
			R > plot: Use Httpgd
			Search for "Editor: insert spaces". Unselect to use tabs
			To ignore tabs, search for "Flake8 Args", click Add Item and paste in "--ignore=W191"

4. Finish up!
	In Conda:
		Python3 or R
	VS Code:
		shift-return to execute python
		control-return to execute R
		Start VS Code in a WSL, open windows terminal, navigate to directory and type:
			code ./

## SETTING UP LINUX
1. Run WSL setup; from home:
	bash DataScience_SetUp_v1_Ubuntu.sh
	bash DataScience_SetUp_v1_Ubuntu_CondaLibs.sh
	
## REMOTE
1. Remote development using SSH:
	1. Test ssh in terminal (e.g., to a raspberry pie):
		pi@192.168.1.87 (normally ssh: ssh pi@192.168.1.87, pwd: raspberry)
	2. In VS Code, select Remote-SSH: Connect to Host... from the Command Palette (F1 or >< in lower left corner) 
	3. 'exit' to logoff of ssh
	
	SSH into WSL from external computer setup:
	1. on host WSL:
		sudo apt-get purge openssh-serversudo 
		apt-get install openssh-serversudo
		nano /etc/ssh/sshd_config
			Port 2222
			PasswordAuthentication yes
		sudo service ssh start
		ip addr (record ip address)
	2. on host Windows powershell (as admin):
		netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=2222 connectaddress=172.24.97.151 connectport=2222
			connectaddress is the wsl address
		Start-Service sshd Set-Service -Name sshd -StartupType 'Automatic'
		netsh advfirewall firewall add rule name=”Open Port 2222 for WSL2” dir=in action=allow protocol=TCP localport=2222
	3. on client:
		ssh organ@192.168.1.89 -p 2222
			organ is wsl2 user id on host
			use internal network windows (host) ip address
	4. SSH into Windows:
		1. Locally, just : click on remote, then SSH-Remote: Connect to Host
			nestor@elysion
				where 'nestor' is the Windows user id and elysion is the name of the machine
		2. SSH into Windows:
			ssh nestor@192.168.1.89 -p 22
			ssh nestor@elysion
			where 'nestor' is the Windows user id and the ip is the internal network ip
