# Install Conda libraries
conda activate
conda config --add channels bioconda
conda config --add channels conda-forge
conda config --add channels r
conda config --set channel_priority false
conda install git pip flake8 -y
conda install ipython jupyterlab ipykernel pytest pytest-xdist -y
conda install ply pathlib line_profiler memory_profiler -y
conda install numpy pandas scipy scikit-learn statsmodels -y
conda install matplotlib seaborn bokeh dash -y
conda install cython numba dask rpy2 pystan stan -y
conda install -c conda-forge pymc3 -y
conda install mkl-service -y
conda install biopython -y
conda install -c r r-irkernel -y
conda install -c r-essentials -y
conda install -c conda-forge r-lme4 -y
conda install -c conda-forge r-mcmcglmm -y
conda install -c conda-forge r-ape -y
conda install -c conda-forge r-phytools -y
conda install -c conda-forge r-mcmcglmm -y
conda update --all -y
conda clean --all -y
