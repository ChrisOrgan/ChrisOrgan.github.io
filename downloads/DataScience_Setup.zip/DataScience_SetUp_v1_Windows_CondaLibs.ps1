# Install Conda libraries
conda install git pip flake8 -y
conda install ipython jupyterlab ipykernel pytest pytest-xdist -y
conda install ply pathlib line_profiler memory_profiler -y
conda install numpy pandas scipy scikit-learn statsmodels -y
conda install matplotlib seaborn bokeh dash -y
conda install cython numba dask -y
conda install -c conda-forge cyipopt -y
conda install -c conda-forge pymc -y
conda install mkl-service -y
conda install biopython -y
conda install rpy2 -y
conda install -c r r-irkernel -y
conda install -c r-essentials -yS
conda install -c conda-forge radian -y
conda install -c conda-forge r-languageserver -y
conda install -c conda-forge r-tidyverse -y
conda install -c conda-forge r-lme4 -y
conda install -c conda-forge r-mcmcglmm -y
conda install -c conda-forge r-ape -y
conda install -c conda-forge r-phytools -y
conda install -c conda-forge r-mcmcglmm -y
conda update --all -y
conda clean --all -y
