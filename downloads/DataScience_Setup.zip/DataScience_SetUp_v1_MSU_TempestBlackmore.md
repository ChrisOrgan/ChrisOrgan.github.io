# RESEARCH CYBERINFRASTRUCTURE: TEMPEST & BLACKMORE
- Coltran Hophan-Nichols (coltran@montana.edu): High level contact
- tempest-support@montana.edu for general questions

## GRANT INFO
- https://www.montana.edu/uit/rci/tempest/cluster-description-grant-template/index.html

## MSU VPN
https://www.montana.edu/uit/computing/desktop/vpn/
- 	vpn.msu.montana.edu
	Group: MSU-Employee-VPN or MSU-Student-VPN
	NetID and NetID Password (then Duo)

## BLACKMORE
- Blackmoore: Data storage
	- 25 Tb storage
	- Setup: https://www.montana.edu/uit/rci/blackmore/
- (Windows) \\blackmore.msu.montana.edu\erthsci-deeptimebio-lab or (OSX/Linux) //blackmore.msu.montana.edu/erthsci-deeptimebio-lab
	- NetID and NetID Password
	
- **Globus (large file transfer)**
	1. https://globus.org
	2. Login, select organization
	- Collections
		- montana#tempest
		- montana#blackmore	
		
## TEMPEST
- https://www.montana.edu/uit/rci/tempest/
- Status: https://grafana.msu.montana.edu/d/BF9ObRwMk/tempest-public?orgId=1&refresh=1m
- Free tier (per lab)
	- Priority access to a node, each of which has:
		- 256 CPUs
		- 1 Tb memory
		- 2 GPUs
		- Each user has up to 10 Tb storage
		- Group user has up to 10 Tb storage
	- Unsafe workloads
		- Can use, but can be cancelled by priority
- Free tier (per class)
	- same stats as lab

- /home/group/x84r598
- /home/group/chrisorgan # For lab8


- **SSH (from terminal, must be on VPN)**
	1. ssh-keygen # from the command line. If you don’t have existing keys, accept the defaults (don't enter password).
	2. cat .ssh/id_rsa.pub (should see key)
	3. Select that text and copy it.
	4. Login to https://www.montana.edu/uit/rci/tempest/
	5. Select Files > Home Directory 
	6. Check the box to Show Dotfiles
	8. Brows to .ssh / authorized_keys, select the … and click Edit
	9. Add a new line to the bottom of the file and paste your ssh key from step 2 & save
	10. You should now be able to ssh to the login node with
		ssh YourNetID@tempest-login.msu.montana.edu	

- **FTP (MobaXTerm or WinSCP)**
	- tempest-login.msu.montana.edu
	- NETID
	- port 22
	- Authentication: private ssh key file

- **Running programs**
	- module avial
	- ms <program name> # search for module
	- module load <module name>
	- supports docker & singularity
	- Syntax
		- module load Mamba
			- R
			- python
		- module load MrBayes
		  mpirun -np 4 mb
		- module load MAFFT

- **Running jobs & Slurm**
	- Don't run software in login (head) node! Run sbatch job using Slurm
	- sacct # Shows job status
	- squeue -p gputest # Shows qued jobs on gputest partition
	- sqf # Show all jobs running
	- tail -f <output file> # track job output
	- scontrol show jobid -dd <jobid> # To view status of job
	- scancel <jobid>
	- **Partitions:**
		- test 1 hour 8 CPUs, 32G mem per user for testing group
		- priority 14 days 256 CPUs, 1024G Mem per group, plus contribution for most jobs priority
		- unsafe 7 days all unused (EPYC) jobs may be preempted group
		- interactive 14 days 64 CPUs, 256G Mem per user, from priority allocation for interactive apps only priority 
		- gputest 30 min 8 CPUs, 32G mem, 1 GPU per user for GPU testing group
		- gpupriority 14 days 2 GPUs (up to 1 A100) per group, plus contribution for most GPU jobs priority
		- gpuunsafe 7 days all unused (GPU) jobs may be preempted group
		- legacy 7 days all unused (xeon) – may need to recompile software good for many small jobs group
	- run Slurm job file: sbatch SlurmJob.sh
	
- **Interactive Jobs**
	- This will give you an interactive session on a compute node from which you can install, test, and run programs.
	- from the Tempest login node:
	srun --cpus-per-task=2 --mem=2G --partition=priority --account=<priority-account> --time=02:00:00 --pty bash -i
	(adding your priority account name and modifying the CPU, memory, and time parameters as desired) 

	- type "exit" to end the interactive job and return to the login node.
	
	

	
	