# SETTING UP A DATA SCIENCE ENVIRONMENT (Windows, Linux, & OSX)

# WINDOWS
## SETTING UP WINDOWS LINUX SUBSYSTEM
1. Open powershell in admin
2. type 'wsl --install'
3. Install Winget: https://apps.microsoft.com/detail/9NBLGGH4NNS1?hl=en-us&gl=US#activetab=pivot:overviewtab
4. Reboot

## SETTING UP WINDOWS
1. Windows & Miniforge (Conda/Mamba) setup:
	1. Install MesloLGS nerd font from this folder (or any font from https://www.nerdfonts.com/font-downloads)
	2. Install Miniforge: https://github.com/conda-forge/miniforge
	3. Open "DataScience_SetUp_v1_Windows.ps1" and change user name from "USR_NAME" to your own user name
	4. Run powershell (admin) and run:
		.\DataScience_SetUp_v2_Windows.ps1
	5. Restart powershell (admin) and run:
		.\DataScience_SetUp_v2_Windows_CondaLibs.ps1	
		
	Note: For the conda environment to appear in Oh-My-Posh, make sure the theme file,
		C:\Users\USR_NAME\AppData\Local\Programs\oh-my-posh\themes
		has this section, or replace the python section with this:
		{
          "background": "#FF6471",
          "foreground": "#ffffff",
          "leading_diamond": "<transparent,background>\ue0b0</>",
          "style": "diamond",
          "template": " {{ if .Error }}{{ .Error }}{{ else }}{{ if .Venv }}{{ .Venv }} {{ end }}{{ .Full }}{{ end }} ",
          "trailing_diamond": "\ue0b4",
          "type": "python",
		  "properties": {
			"home_enabled": true,
			"display_mode": "environment",
			"fetch_virtual_env": true
		  }
		}
			
2. Windows Terminal setup
	1. install from Windows Store if not installed
	2. Open settings for terminal
	3. Set as default application and default profile to Ubutnu
	4. In settings, select RobotoMono Nerd Font for powershell & Ubuntu
	5. To hide shells (like azure and the old powershell) change "hidden": true in their guids
	
3. Install VS Code with plugins in Windows
	Extensions:
		Better Comments
		Code Spell Checker
		Code Runner
		Edit csv
		GitHub Repositories
		Git Graph
		Path Intellisense
		Markdownlint
		Python
		Flake8
		autoDocstring
		Jupyter
		R
		R Debugger
		Remote SSH, WSL, Development, Containers
		YAML
		vscode-pandoc
	Settings:
		Enter command palette (ctrl-shift-p)
			- type "python interpreter" and navigate to ~\miniforge\envs\DataScience\python.exe
		In Settings (change user name accordingly):
			Check box: "Jupyter > interactive window > text editor: execute selection
			Search for "Editor: insert spaces". Unselect to use tabs
			To ignore tabs, search for "Flake8 Args", click Add Item and paste in "--ignore=W191"
		Open command palette (ctrl-shift-p), and search for "open user settings (JSON)", replace r settings with:
			"r.helpPanel.enableHoverLinks": false,
			"r.bracketedPaste": true,
			"r.lsp.diagnostics": true,
			"r.lsp.enabled": true,
			"r.bracketedPaste": true,
			"r.rpath.windows": "C:\\Users\\Nestor\\miniforge3\\envs\\DataScience\\Lib\\R\\bin\\R.exe",
			"r.rterm.windows": "C:\\Users\\Nestor\\miniforge3\\envs\\DataScience\\Scripts\\radian.exe",
			"r.lsp.path": "C:\\Users\\Nestor\\miniforge3\\envs\\DataScience\\Lib\\R\\bin\\R.exe",
			"r.lsp.debug": true,
			"r.lsp.diagnostics": true,
			"r.rterm.option": ["--no-save","--no-restore","--r-binary=C:\\Users\\Nestor\\miniforge3\\envs\\DataScience\\Lib\\R\\bin\\R.exe"]
			"files.associations", change "rmd" to rmd (instead of markdown)
	
4. Finish up!
	In shell:
		Activate correct environment (conda activate DataScience)
		Python or R.exe (R in linux)
	VS Code:
		Python:
			Select correct environment in the bottom blue status bar
			Shift-return to execute in interactive python
		R: 
			Activate correct environment (mamba activate DataScience) in powershell
			Start vscode from powershell by typing: code 
			Control-return to execute lines in R
		From WSL: open terminal, navigate to directory, then:
			code ./

# LINUX
1. From home run:
	bash DataScience_SetUp_v2_Ubuntu.sh
	bash DataScience_SetUp_v2_Ubuntu_CondaLibs.sh

# OSX
1. Install MesloLGS NF fonts from this folder (or https://github.com/romkatv/dotfiles-public/tree/master/.local/share/fonts/NerdFonts)
1. In terminal, run:
	bash DataScience_SetUp_v2_OSX.sh
	bash DataScience_SetUp_v2_OSX_CondaLibs.sh
	
# REMOTE
1. Remote development using SSH:
	1. Test ssh in terminal (e.g., to a raspberry pie):
		pi@192.168.1.87 (normally ssh: ssh pi@192.168.1.87, pwd: raspberry)
	2. In VS Code, select Remote-SSH: Connect to Host... from the Command Palette (F1 or >< in lower left corner) 
	3. 'exit' to logoff of ssh
	
	SSH into WSL from external computer setup:
	1. on host WSL:
		sudo apt-get purge openssh-serversudo 
		apt-get install openssh-serversudo
		nano /etc/ssh/sshd_config
			Port 2222
			PasswordAuthentication yes
		sudo service ssh start
		ip addr (record ip address)
	2. on host Windows powershell (as admin):
		netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=2222 connectaddress=172.24.97.151 connectport=2222
			connectaddress is the wsl address
		Start-Service sshd Set-Service -Name sshd -StartupType 'Automatic'
		netsh advfirewall firewall add rule name=”Open Port 2222 for WSL2” dir=in action=allow protocol=TCP localport=2222
	3. on client:
		ssh organ@192.168.1.89 -p 2222
			organ is wsl2 user id on host
			use internal network windows (host) ip address
	4. SSH into Windows:
		1. Locally, just : click on remote, then SSH-Remote: Connect to Host
			nestor@elysion
				where 'nestor' is the Windows user id and elysion is the name of the machine
		2. SSH into Windows:
			ssh nestor@192.168.1.89 -p 22
			ssh nestor@elysion
			where 'nestor' is the Windows user id and the ip is the internal network ip
