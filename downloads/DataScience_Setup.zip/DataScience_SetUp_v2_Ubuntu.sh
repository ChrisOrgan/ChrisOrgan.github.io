#!/bin/bash

# Bash linux setup
sudo apt update # updates the package sources list to get the latest list of available packages in the repositories
sudo apt upgrade -y	# updates all the packages presently installed in our Linux system to their latest versions

# Install curl, git, zip
sudo apt-get install -y curl git zip unzip

# Compilers & Java
sudo apt-get install autoconf automake make gcc perl zlib1g-dev libbz2-dev liblzma-dev libcurl4-gnutls-dev libssl-dev # required packages for the htslib bio-informatics package
sudo apt-get install -y cmake g++ build-essential libtool libreadline-dev pkg-config openjdk-11-jdk
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64

# Install zsh
# If installing on WSL, make sure to install Windows Terminal, set profile, and fonts beforehand
sudo apt-get install zsh -y
sudo chsh -s $(which zsh)
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
git clone https://github.com/zsh-users/zsh-autosuggestions.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions

# sed prepends text to file (as opposed to appending)
sed -i '1i export PATH=$HOME/bin:/usr/local/bin:$PATH' ~/.zshrc
echo 'plugins=(git zsh-autosuggestions zsh-syntax-highlighting)' >> ~/.zshrc
echo 'ZSH_DISABLE_COMPFIX="true"' >> ~/.zshrc
echo 'alias ll='ls -l'' >> ~/.zshrc
sed -i '1i if test -t 1; then exec zsh; fi' ~/.bashrc

# change "==" to "=" so that the script is compatible with zsh
sed -i 's/==/=/g' ~/miniconda3/etc/conda/activate.d/java_home.sh

# Install Oh-My-Posh
sudo wget https://github.com/JanDeDobbeleer/oh-my-posh/releases/latest/download/posh-linux-amd64 -O /usr/local/bin/oh-my-posh
sudo chmod +x /usr/local/bin/oh-my-posh

# Themes for Oh-My-Posh
mkdir ~/.poshthemes
wget https://github.com/JanDeDobbeleer/oh-my-posh/releases/latest/download/themes.zip -O ~/.poshthemes/themes.zip
unzip ~/.poshthemes/themes.zip -d ~/.poshthemes
chmod u+rw ~/.poshthemes/*.omp.*
rm ~/.poshthemes/themes.zip

# Setup shell
sed -i '1i eval "$(oh-my-posh init zsh --config ~/.poshthemes/aliens.omp.json)"' ~/.zshrc

# Install Pandoc
sudo apt-get install -y pandoc
 
# Install Miniforge (a conda derivative)
wget -O Miniforge3.sh "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-$(uname)-$(uname -m).sh"
bash Miniforge3.sh -b -p "${HOME}/conda"
~/conda/bin/conda init bash
~/conda/bin/mamba init bash
~/conda/bin/conda init zsh
~/conda/bin/mamba init zsh

# Restart shell
source .zshrc
mamba create -n DataScience
conda activate DataScience
rm -rf ~/Miniforge3.sh


# Install R
sudo apt install --no-install-recommends software-properties-common dirmngr
wget -qO- https://cloud.r-project.org/bin/linux/ubuntu/marutter_pubkey.asc | sudo tee -a /etc/apt/trusted.gpg.d/cran_ubuntu_key.asc
sudo add-apt-repository "deb https://cloud.r-project.org/bin/linux/ubuntu $(lsb_release -cs)-cran40/"
sudo apt install --no-install-recommends r-base
sudo add-apt-repository ppa:c2d4u.team/c2d4u4.0+

# Setup BayesTraits
# to Run:
# BayesTraitsV4 Marsupials.trees Marsupials.txt
mkdir ~/bin 
cd ~/bin
curl -O http://www.evolution.reading.ac.uk/BayesTraitsV4.1.1/Files/BayesTraitsV4.1.1-Linux.tar.gz
tar zxvf BayesTraitsV4.1.1-Linux.tar.gz
rm BayesTraitsV4.1.1-Linux.tar.gz
cd ~
sed -i '1i export PATH=~/bin/BayesTraitsV4.1.1-Linux:$PATH' ~/.bashrc
sed -i '1i export PATH=~/bin/BayesTraitsV4.1.1-Linux:$PATH' ~/.zshrc

# Restart shell
source .zshrc
