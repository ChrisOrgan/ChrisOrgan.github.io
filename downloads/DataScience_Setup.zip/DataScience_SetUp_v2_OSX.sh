#!/bin/bash

# Install Xcode
xcode-select --install

# Install Homebrew (terminal package manager)
curl -fsSL -o install.sh https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh
bash Miniforge3.sh -b -p "${HOME}/conda"

# Add Homebrew's executable directory to the front of the PATH: Change .bash_profile to .zshrc if using z-shell
sed -i 'export PATH=/usr/local/bin:$PATH' ~/.bash_profile

# Install vs-code
brew install --cask visual-studio-code

# Install Oh-My-Posh
brew install jandedobbeleer/oh-my-posh/oh-my-posh
brew update && brew upgrade oh-my-posh
chmod +x /usr/local/bin/oh-my-posh

# Themes for Oh-My-Posh
mkdir ~/.poshthemes
wget https://github.com/JanDeDobbeleer/oh-my-posh/releases/latest/download/themes.zip -O ~/.poshthemes/themes.zip
unzip ~/.poshthemes/themes.zip -d ~/.poshthemes
chmod u+rw ~/.poshthemes/*.omp.*
rm ~/.poshthemes/themes.zip

# Setup shell
sed -i '1i eval "$(oh-my-posh init zsh)"' ~/.bash_profile

# Install Java
brew install java

# Install r
brew install r

# INstall Pandoc
brew install pandoc

# Install Miniforge (a conda derivative)
wget https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-MacOSX-arm64.sh -P ~/Downloads/
chmod +x ~/Downloads/Miniforge3-MacOSX-arm64.sh # make the file executable
sh ~/Downloads/Miniforge3-MacOSX-arm64.sh -b -p ~/conda # installs in the home directory in conda
source "${HOME}/conda/etc/profile.d/conda.sh"
source "${HOME}/conda/etc/profile.d/mamba.sh"
mamba create -n DataScience
conda activate DataScience
rm -rf ~/Downloads/Miniforge3.sh
