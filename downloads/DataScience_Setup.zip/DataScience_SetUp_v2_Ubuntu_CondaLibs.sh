#!/bin/bash

# Activate the environment you want to install packages in
mamba activate DataScience

# Install Conda libraries
mamba install git pip flake8 -y
mamba install ipython jupyterlab ipykernel pytest pytest-xdist -y
mamba install ply pathlib line_profiler memory_profiler -y
mamba install numpy pandas scipy scikit-learn statsmodels -y
mamba install matplotlib seaborn bokeh dash -y
mamba install cython numba dask -y
mamba install cyipopt pymc -y
mamba install mkl-service -y
mamba install biopython -y
mamba install rpy2 r-irkernel r-essentials -y
mamba install radian r-languageserver r-tidyverse -y
mamba install r-lme4 r-mcmcglmm r-ape r-phytools -y
mamba install -c bioconda r-phytools -y
mamba install -c bioconda mafft muscle -y
mamba install -c bioconda iqtree phylip raxml-ng -y
mamba install -c bioconda PhyML mrbayes beast2 revbayes -y
mamba update --all -y
mamba clean --all -y
