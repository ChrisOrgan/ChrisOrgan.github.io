#!/bin/bash

# Bash linux setup
sudo apt update # updates the package sources list to get the latest list of available packages in the repositories
sudo apt upgrade -y	# updates all the packages presently installed in our Linux system to their latest versions

# Install curl, git, zip
sudo apt-get install curl
sudo apt-get install git
sudo apt-get install zip unzip

# Compilers C and C++ programs under WSL with GCC, you can install it with:
sudo apt install build-essential -y
sudo apt-get install autoconf automake make gcc perl zlib1g-dev libbz2-dev liblzma-dev libcurl4-gnutls-dev libssl-dev # required packages for the htslib bio-informatics package

# Install zsh
# If installing on WSL, make sure to install Windows Terminal, set profile, and fonts beforehand
sudo apt-get install zsh -y
sudo chsh -s $(which zsh)
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
git clone https://github.com/zsh-users/zsh-autosuggestions.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions

# sed prepends text to file (as opposed to appending)
sed -i '1i export PATH=$HOME/bin:/usr/local/bin:$PATH' ~/.zshrc
echo 'plugins=(git zsh-autosuggestions zsh-syntax-highlighting)' >> ~/.zshrc
echo 'ZSH_DISABLE_COMPFIX="true"' >> ~/.zshrc
echo 'alias ll='ls -l'' >> ~/.zshrc
sed -i '1i if test -t 1; then exec zsh; fi' ~/.bashrc



# change "==" to "=" so that the script is compatible with zsh
sed -i 's/==/=/g' ~/miniconda3/etc/conda/activate.d/java_home.sh

# Install Oh-My-Posh
sudo wget https://github.com/JanDeDobbeleer/oh-my-posh/releases/latest/download/posh-linux-amd64 -O /usr/local/bin/oh-my-posh
sudo chmod +x /usr/local/bin/oh-my-posh

# Themes for Oh-My-Posh
mkdir ~/.poshthemes
wget https://github.com/JanDeDobbeleer/oh-my-posh/releases/latest/download/themes.zip -O ~/.poshthemes/themes.zip
unzip ~/.poshthemes/themes.zip -d ~/.poshthemes
chmod u+rw ~/.poshthemes/*.omp.*
rm ~/.poshthemes/themes.zip

# Setup shell
sed -i '1i eval "$(oh-my-posh init zsh)"' ~/.zshrc

# Set up Miniconda
mkdir -p ~/miniconda3
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -O ~/miniconda3/miniconda.sh
bash ~/miniconda3/miniconda.sh -b -u -p ~/miniconda3
rm -rf ~/miniconda3/miniconda.sh
~/miniconda3/bin/conda init bash
~/miniconda3/bin/conda init zsh

# Setup BayesTraits
# to Run:
# BayesTraitsV4 Marsupials.trees Marsupials.txt
cd /usr/local/bin
sudo curl -O http://www.evolution.reading.ac.uk/BayesTraitsV4.0.0/Files/BayesTraitsV4.0.0-Linux.tar.gz
sudo tar zxvf BayesTraitsV4.0.0-Linux.tar.gz
sudo rm BayesTraitsV4.0.0-Linux.tar.gz
cd ~
sed -i '1i export PATH=/usr/local/bin/BayesTraitsV4.0.0-Linux:$PATH' ~/.bashrc

# To restart shell & configure:
source .zshrc


