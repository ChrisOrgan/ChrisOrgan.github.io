# Activate the environment you want to install packages in
mamba create -n DataScience
conda activate DataScience

# To install more R libraries: mamba install r-<package-name>
mamba install git pip flake8 -y
mamba install ipython jupyterlab ipykernel pytest pytest-xdist -y
mamba install ply pathlib line_profiler memory_profiler -y
mamba install numpy pandas scipy scikit-learn statsmodels -y
mamba install matplotlib seaborn bokeh dash -y
mamba install cython numba dask -y
mamba install cyipopt pymc -y
mamba install mkl-service -y
mamba install biopython -y
mamba install rpy2 r-irkernel r-essentials radian -y
mamba update --all -y
mamba clean --all -y
