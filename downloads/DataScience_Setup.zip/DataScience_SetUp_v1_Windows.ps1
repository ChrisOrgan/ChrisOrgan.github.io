# Windows environmental setup script: Must be run as admin
# auto confirm with: ECHO Y |  

# # Install winget
Get-AppxPackage microsoft.DesktopAppInstaller

# Get new powershell
winget install --id Microsoft.Powershell --source winget

# Install Windows Terminal
winget install Microsoft.WindowsTerminal

# Set policies
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted

# Set paths
Setx PATH "%PATH%;C:\Users\Battuto\Miniconda3;C:\Users\Battuto\Miniconda3\Scripts;C:\Users\Battuto\Miniconda3\Lib;C:\Users\Battuto\Miniconda3\Library;C:\Users\Battuto\Miniconda3\Library\bin"
		
# Initialize Conda for powershell
conda init powershell
conda activate
conda install -n base conda-libmamba-solver -y
conda config --append channels conda-forge
conda config --append channels bioconda
conda config --append channels r
conda config --set channel_priority strict
conda config --set solver libmamba

# Install OpenSSH in Windows
Get-WindowsCapability -Online | ? Name -like 'OpenSSH*'
Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Get OhMyPosh & PoshGit for powershell
winget install JanDeDobbeleer.OhMyPosh -s winget
Install-Module posh-git -Scope CurrentUser -Force
Install-Module -Name PSReadLine -AllowPrerelease -Scope CurrentUser -Force -SkipPublisherCheck