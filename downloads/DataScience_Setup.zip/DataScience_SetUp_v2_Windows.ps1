# Windows environmental setup script: Must be run as admin
# Change user name from "USR_NAME" to your own user name
# auto confirm with: ECHO Y |  

# # Install winget
Get-AppxPackage microsoft.DesktopAppInstaller

# Get new powershell
winget install --id Microsoft.Powershell --source winget

# Install Windows Terminal
winget install Microsoft.WindowsTerminal

# Set policies
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted

# Set paths for Miniforge
# Retrieve the current PATH
$currentPath = [System.Environment]::GetEnvironmentVariable('PATH', [System.EnvironmentVariableTarget]::User)

# Define the new directory to add
# Make sure that "DataScience" here matches the name of your environment below
$newPath = "C:\Users\USR_NAME\miniforge3\condabin;C:\Users\USR_NAME\miniforge3\envs\DataScience\Library\lib\R\bin"

# Append the new directory to the current PATH
$newPathEntry = $currentPath + ";" + $newPath

# Update the PATH
[System.Environment]::SetEnvironmentVariable('PATH', $newPathEntry, [System.EnvironmentVariableTarget]::User)

# Initialize Mamba for powershell & create working environment
# mamba env list
# mamba list
mamba init powershell

# Install OpenSSH in Windows
Get-WindowsCapability -Online | ? Name -like 'OpenSSH*'
Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Get OhMyPosh & PoshGit for powershell
# Paths should be:
# 	C:\Users\USR_NAME\AppData\Local\oh-my-posh
# 	C:\Users\USR_NAME\AppData\Local\Programs\oh-my-posh\bin
#   C:\Users\USR_NAME\AppData\Local\Programs\oh-my-posh\themes
winget install JanDeDobbeleer.OhMyPosh -s winget
Install-Module posh-git -Scope CurrentUser -Force
Install-Module -Name PSReadLine -AllowPrerelease -Scope CurrentUser -Force -SkipPublisherCheck

# Update Powershell user profile
# Note: change "aliens" to any other theme name
# To run with basic theme: oh-my-posh --init --shell pwsh | Invoke-Expression
Add-Content -Path ~\Documents\PowerShell\profile.ps1 -Value 'oh-my-posh init pwsh --config "$env:POSH_THEMES_PATH\aliens.omp.json" | Invoke-Expression'

# Install Pandoc
winget install --source winget --exact --id JohnMacFarlane.Pandoc
		
		